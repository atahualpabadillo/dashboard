import React, { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts'
import { Target, CheckCircle2, Clock, Flag, History, Upload, Download, RefreshCw } from 'lucide-react'

const STORAGE_KEY = 'ieltsDashboardAta_v1'
const todayISO = new Date().toISOString().slice(0,10)

const initialState = {
  meta: { testDate: '2025-08-31', weeklyTargetHours: 22 },
  scores: {
    Writing: { current: 5.5, shortTerm: 6.0, target: 6.5 },
    Speaking: { current: 6.0, target: 6.5 },
    Listening: { current: 6.0, target: 6.5 },
    Reading: { current: 7.0, target: 6.5 },
  },
  allocation: { Writing: 55, Speaking: 27, Listening: 18, Reading: 0 },
  focusAreas: [
    'WT2: Introducciones claras y directas',
    'WT2: Párrafos con 1 idea + desarrollo',
    'Gramática: oraciones complejas seguras (Band 6-6.5)',
    'Speaking: ritmo y enlaces (fluidez)',
    'Listening: MCQ y Summary Completion',
  ],
  errorKiller: [
    { id: 'ek1', text: 'Artículos (a/an/the) y plurales', done: false },
    { id: 'ek2', text: 'Preposiciones (in/on/at, to/for)', done: false },
    { id: 'ek3', text: 'Subject-verb agreement', done: false },
    { id: 'ek4', text: 'Comas y puntuación en WT2', done: false },
    { id: 'ek5', text: 'Conectores (however, whereas, therefore) sin sobreusar', done: false },
  ],
  tasks: [
    { id: 't1', date: '2025-08-12', title: 'Speaking M6-7 (Vocab+Grammar) → precisión 6.5', type: 'Speaking', done: false },
    { id: 't2', date: '2025-08-13', title: 'WT2 M9 (Discussion) + M10 (Problems/solutions): 2 ensayos', type: 'Writing', done: false },
    { id: 't3', date: '2025-08-14', title: 'Listening M5 (Matching) + M6 (Map/Plan): práctica cronometrada', type: 'Listening', done: false },
    { id: 't4', date: '2025-08-15', title: 'WT2 M11 + M12: 2 ensayos → feedback #3', type: 'Writing', done: false },
    { id: 't5', date: '2025-08-16', title: 'WT1 M7-12: practicar tipos más débiles', type: 'Writing', done: false },
    { id: 't6', date: '2025-08-17', title: 'Speaking M8-10 → mock completo', type: 'Speaking', done: false },
    { id: 't7', date: '2025-08-18', title: 'Gramática IELTS M1-4 + aplicar a 1 ensayo', type: 'Grammar', done: false },
    { id: 't8', date: '2025-08-19', title: 'Listening M7-12 → detectar tipos débiles', type: 'Listening', done: false },
    { id: 't9', date: '2025-08-20', title: 'Gramática IELTS M5-8 + revisar ensayos', type: 'Grammar', done: false },
    { id: 't10', date: '2025-08-21', title: 'Speaking M11-12 → mock + grabación', type: 'Speaking', done: false },
    { id: 't11', date: '2025-08-22', title: 'Gramática IELTS M9-16 + 3 ensayos → feedback #4', type: 'Grammar', done: false },
    { id: 't12', date: '2025-08-23', title: 'Mock test completo (4 skills) cronometrado', type: 'Mock', done: false },
    { id: 't13', date: '2025-08-24', title: '1:1 #2 + estrategia final + enviar WT (feedback #5)', type: 'Coaching', done: false },
    { id: 't14', date: '2025-08-25', title: 'WT2 con tiempo (40 min)', type: 'Writing', done: false },
    { id: 't15', date: '2025-08-26', title: 'Speaking 3 partes (sin contenido nuevo)', type: 'Speaking', done: false },
    { id: 't16', date: '2025-08-27', title: 'Listening test + revisión de errores', type: 'Listening', done: false },
    { id: 't17', date: '2025-08-28', title: 'WT1 + WT2 limpios + repasar procedimiento', type: 'Writing', done: false },
    { id: 't18', date: '2025-08-29', title: 'Mock final + preparar materiales + descanso', type: 'Mock', done: false },
    { id: 't19', date: '2025-08-30', title: 'Práctica ligera (≤2h) + revisar sede + dormir', type: 'Light', done: false },
  ],
  logs: [],
  feedback: [],
}

const loadState = () => {
  try{ const raw = localStorage.getItem(STORAGE_KEY); return raw? JSON.parse(raw): null } catch(_) { return null }
}
const saveState = (s) => { try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(s)) } catch(_) {} }

const hoursToMinutes = (h)=> Math.round(h*60)
const minutesToHHMM = (m)=> `${Math.floor(m/60)}h ${m%60}m`
const withinWeek = (dateStr)=>{
  const d = new Date(dateStr); const now = new Date()
  const day = (now.getDay()+6)%7
  const monday = new Date(now); monday.setDate(now.getDate()-day); monday.setHours(0,0,0,0)
  const sunday = new Date(monday); sunday.setDate(monday.getDate()+6); sunday.setHours(23,59,59,999)
  return d>=monday && d<=sunday
}

export default function App(){
  const [state, setState] = useState(()=> loadState() || initialState)
  const [newFocus, setNewFocus] = useState('')
  const [logDraft, setLogDraft] = useState({ date: todayISO, writingMin:'', speakingMin:'', listeningMin:'', essays:'', task1:'', notes:'' })
  const [filter, setFilter] = useState({ query:'', type:'All', showOnlyPending:false, weekOnly:false })

  useEffect(()=> saveState(state), [state])

  const minutesThisWeek = useMemo(()=> state.logs.filter(l=>withinWeek(l.date))
    .reduce((a,l)=> a+Number(l.writingMin||0)+Number(l.speakingMin||0)+Number(l.listeningMin||0),0), [state.logs])
  const weeklyTargetMin = useMemo(()=> hoursToMinutes(state.meta.weeklyTargetHours), [state.meta.weeklyTargetHours])
  const weeklyPct = Math.min(100, Math.round((minutesThisWeek/weeklyTargetMin)*100))

  const skillProgress = useMemo(()=>{
    const { scores } = state
    const pct = (cur,tgt)=>{
      const base = 4.0
      return Math.max(0, Math.min(100, Math.round(((cur-base)/(tgt-base))*100)))
    }
    return [
      { name:'Writing', value:pct(scores.Writing.current, scores.Writing.target) },
      { name:'Speaking', value:pct(scores.Speaking.current, scores.Speaking.target) },
      { name:'Listening', value:pct(scores.Listening.current, scores.Listening.target) },
      { name:'Reading', value:pct(scores.Reading.current, scores.Reading.target) },
    ]
  }, [state])

  const filteredTasks = useMemo(()=> state.tasks.filter(t=>{
    if(filter.type!=='All' && t.type!==filter.type) return false
    if(filter.showOnlyPending && t.done) return false
    if(filter.weekOnly && !withinWeek(t.date)) return false
    if(filter.query && !(t.title+' '+t.type).toLowerCase().includes(filter.query.toLowerCase())) return false
    return true
  }), [state.tasks, filter])

  const toggleTask = (id)=> setState(s=> ({ ...s, tasks: s.tasks.map(t=> t.id===id? {...t, done:!t.done}:t) }))
  const addFocus = ()=>{
    const text = newFocus.trim(); if(!text) return
    setState(s=> ({ ...s, focusAreas: [...s.focusAreas, text] })); setNewFocus('')
  }
  const removeFocus = (idx)=> setState(s=> ({ ...s, focusAreas: s.focusAreas.filter((_,i)=> i!==idx) }))
  const addLog = ()=>{
    const d = { ...logDraft }
    if(!d.date) d.date = todayISO
    ;['writingMin','speakingMin','listeningMin','essays','task1'].forEach(k=> d[k] = Number(d[k]||0))
    setState(s=> ({ ...s, logs: [{...d}, ...s.logs] }))
    setLogDraft({ date: todayISO, writingMin:'', speakingMin:'', listeningMin:'', essays:'', task1:'', notes:'' })
  }
  const addFeedback = (note)=> setState(s=> ({ ...s, feedback: [{ date:new Date().toISOString().slice(0,10), note }, ...s.feedback] }))
  const resetAll = ()=> { if(confirm('¿Reiniciar todo el dashboard?')) setState(initialState) }
  const exportJSON = ()=>{
    const blob = new Blob([JSON.stringify(state,null,2)], {type:'application/json'})
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href=url; a.download='ielts-dashboard-ata.json'; a.click(); URL.revokeObjectURL(url)
  }
  const importJSON = (ev)=>{
    const f = ev.target.files?.[0]; if(!f) return
    const r = new FileReader(); r.onload=()=>{ try{ setState(JSON.parse(r.result)) } catch{ alert('Archivo inválido') } }; r.readAsText(f)
  }
  const daysToTest = useMemo(()=>{
    const now = new Date(); const td = new Date(state.meta.testDate)
    return Math.max(0, Math.ceil((td.getTime()-now.getTime())/(1000*60*60*24)))
  }, [state.meta.testDate])

  const COLORS = ['#60a5fa','#34d399','#fbbf24','#f472b6']

  return (
    <div className="wrap">
      <motion.div initial={{opacity:0,y:-6}} animate={{opacity:1,y:0}}>
        <h1>Dashboard IELTS – Ata</h1>
        <small>Test: <b>{state.meta.testDate}</b> · Quedan {daysToTest} días.</small>
      </motion.div>

      <div className="grid g4" style={{marginTop:16}}>
        <div className="card">
          <div className="title"><Clock size={16}/>Horas esta semana</div>
          <div className="progress"><span style={{width:`${weeklyPct}%`}}></span></div>
          <div className="kpi" style={{marginTop:6}}>
            <span>{minutesToHHMM(minutesThisWeek)}</span>
            <span>Objetivo: {state.meta.weeklyTargetHours}h</span>
          </div>
          <small className="muted">Distribución: Writing {state.allocation.Writing}%, Speaking {state.allocation.Speaking}%, Listening {state.allocation.Listening}%.</small>
        </div>

        {['Writing','Speaking','Listening','Reading'].map((k, idx)=> (
          <div className="card" key={k}>
            <div className="title"><Target size={16}/>{k}</div>
            <div style={{height:130}}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie dataKey="value" data={[{name:k,value: (skillProgress.find(s=>s.name===k)?.value)||0 }]}
                    cx="50%" cy="50%" innerRadius={40} outerRadius={55} startAngle={90} endAngle={-270}>
                    <Cell fill={COLORS[idx%COLORS.length]} />
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div style={{fontSize:13}}>
              <div><b>Actual:</b> {state.scores[k].current ?? '–'}</div>
              {state.scores[k].shortTerm && <div><b>Meta 30d:</b> {state.scores[k].shortTerm}</div>}
              <div><b>Meta:</b> {state.scores[k].target}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid g3" style={{marginTop:16}}>
        <div className="card" style={{gridColumn:'span 2'}}>
          <div className="title"><Flag size={16}/>Focos concretos</div>
          <div style={{marginBottom:8}}>
            {state.focusAreas.map((f, i)=> (
              <span key={i} className="pill">{f} <button className="ghost" onClick={()=>removeFocus(i)} style={{padding:'2px 6px'}}>✕</button></span>
            ))}
          </div>
          <div className="row">
            <input placeholder="Añadir foco (p. ej., 'WT2: tesis directa')" value={newFocus} onChange={e=>setNewFocus(e.target.value)} style={{flex:1}}/>
            <button onClick={addFocus}>Añadir</button>
          </div>
        </div>

        <div className="card">
          <div className="title">Error Killer</div>
          <div className="list">
            {state.errorKiller.map((e)=> (
              <label key={e.id} className="row" style={{fontSize:14}}>
                <input type="checkbox" checked={e.done} onChange={()=> setState(s=>({...s, errorKiller: s.errorKiller.map(x=> x.id===e.id? {...x, done:!x.done}:x)})) }/>
                <span style={{textDecoration:e.done?'line-through':'none'}}>{e.text}</span>
              </label>
            ))}
          </div>
        </div>
      </div>

      <div className="card" style={{marginTop:16}}>
        <div className="between">
          <div className="title">Agenda del plan</div>
          <div className="row">
            <input placeholder="Buscar..." value={filter.query} onChange={e=>setFilter({...filter, query:e.target.value})}/>
            <select value={filter.type} onChange={e=>setFilter({...filter, type:e.target.value})}>
              {['All','Writing','Listening','Speaking','Grammar','Mock','Coaching','Light'].map(t=> <option key={t} value={t}>{t}</option>)}
            </select>
            <label className="row muted" style={{fontSize:13}}><input type="checkbox" checked={filter.weekOnly} onChange={()=>setFilter({...filter, weekOnly:!filter.weekOnly})}/> Esta semana</label>
            <label className="row muted" style={{fontSize:13}}><input type="checkbox" checked={filter.showOnlyPending} onChange={()=>setFilter({...filter, showOnlyPending:!filter.showOnlyPending})}/> Pendientes</label>
          </div>
        </div>
        <div className="grid g3">
          {filteredTasks.map(t=> (
            <div key={t.id} className={"task"+(t.done?" done":"")}>
              <div className="muted" style={{fontSize:12}}>{t.date}</div>
              <div style={{fontWeight:600, marginTop:6}}>{t.title}</div>
              <div className="between" style={{marginTop:8}}>
                <span className="tag">{t.type}</span>
                <button onClick={()=>toggleTask(t.id)}>{t.done? 'Hecha':'Marcar'}</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="card" style={{marginTop:16}}>
        <div className="title"><History size={16}/>Registro diario</div>
        <div className="grid g4">
          <input type="date" value={logDraft.date} onChange={e=>setLogDraft({...logDraft, date:e.target.value})} />
          <input type="number" placeholder="Writing (min)" value={logDraft.writingMin} onChange={e=>setLogDraft({...logDraft, writingMin:e.target.value})}/>
          <input type="number" placeholder="Speaking (min)" value={logDraft.speakingMin} onChange={e=>setLogDraft({...logDraft, speakingMin:e.target.value})}/>
          <input type="number" placeholder="Listening (min)" value={logDraft.listeningMin} onChange={e=>setLogDraft({...logDraft, listeningMin:e.target.value})}/>
          <input type="number" placeholder="WT2 ensayos" value={logDraft.essays} onChange={e=>setLogDraft({...logDraft, essays:e.target.value})}/>
          <input type="number" placeholder="WT1 informes" value={logDraft.task1} onChange={e=>setLogDraft({...logDraft, task1:e.target.value})}/>
          <input placeholder="Notas" value={logDraft.notes} onChange={e=>setLogDraft({...logDraft, notes:e.target.value})}/>
          <button onClick={addLog}>Añadir</button>
        </div>

        <div className="list" style={{marginTop:10}}>
          {state.logs.length===0 && <small className="muted">Sin registros aún.</small>}
          {state.logs.map((l, idx)=> (
            <div key={idx} className="between" style={{border:'1px solid var(--border)', borderRadius:12, padding:8}}>
              <div style={{fontSize:14}}>
                <div style={{fontWeight:600}}>{l.date}</div>
                <div className="muted" style={{fontSize:12}}>Writing {l.writingMin}m · Speaking {l.speakingMin}m · Listening {l.listeningMin}m · WT2 {l.essays} · WT1 {l.task1}</div>
                {l.notes && <div style={{marginTop:4, fontSize:12}}>Notas: {l.notes}</div>}
              </div>
              <button className="ghost" onClick={()=> setState(s=> ({ ...s, logs: s.logs.filter((_,i)=> i!==idx) }))}>Eliminar</button>
            </div>
          ))}
        </div>
      </div>

      <div className="row" style={{gap:8, marginTop:12}}>
        <button onClick={exportJSON}><Download size={16} style={{marginRight:6}}/>Exportar JSON</button>
        <label className="row" style={{gap:8, border:'1px solid var(--border)', borderRadius:10, padding:'8px 10px'}}>
          <Upload size={16}/> Importar JSON
          <input type="file" accept="application/json" onChange={importJSON} style={{display:'none'}}/>
        </label>
        <button className="ghost" onClick={resetAll}><RefreshCw size={16} style={{marginRight:6}}/>Reiniciar</button>
      </div>

      <div className="card" style={{marginTop:16}}>
        <div className="title">Rutina diaria no-negociable</div>
        <ul style={{marginTop:6, color:'var(--muted)'}}>
          <li>Writing: 60 min mínimo todos los días (ensayo o parte del ensayo).</li>
          <li>Speaking: ≥30 min diarios grabados y revisados.</li>
          <li>Listening: práctica enfocada en tipos débiles.</li>
          <li>Aplicar inmediatamente el feedback recibido.</li>
        </ul>
      </div>

      <div className="footer">Datos guardados en tu navegador (localStorage). Exporta/Importa para respaldo.</div>
    </div>
  )
}
